# Simple Drag and drop

A Pen created on CodePen.

Original URL: [https://codepen.io/Geoffrey-the-vuer/pen/emYgdxj](https://codepen.io/Geoffrey-the-vuer/pen/emYgdxj).

